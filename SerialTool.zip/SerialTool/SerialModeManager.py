import serial
import time, os
from datetime import datetime
import subprocess
import logging
from enum import Enum, auto


# --- Enums ---

class MatchMode(Enum):
    STRICT_END = auto()
    ANY_WHERE = auto()

class DeviceMode(str, Enum):
    IBOOT = 'iboot'
    RTOS = 'rtos'
    LINUX = 'linux'
    LINUX_LOGIN = 'linux_login'
    UNKNOWN = 'unknown'
    
    def __str__(self):
        return self.value

# --- Configuration ---

PROMPT_CONFIG = {
    DeviceMode.RTOS: b'] :-) ',
    DeviceMode.IBOOT: b'\r\n] ',
    DeviceMode.LINUX: b'Phone:~ root# ',
    DeviceMode.LINUX_LOGIN: b'login:',
}
PHONE_PROMPT = list(PROMPT_CONFIG.values()) + [b'Phone:~ mobile$ '] 

class SerialModeManager:
    def __init__(self, port, baudrate=115200, timeout=5, log_file="serial_log.txt", log_to_console=True):
        self.port = port
        # 使用 Port 作为 Logger 名称的一部分，确保每个设备有独立的 Logger 实例
        # 避免设备 A 的日志写到设备 B 的文件中
        safe_port_name = port.replace('/', '_')
        self.logger = logging.getLogger(f"SerialManager.{safe_port_name}")
        self.logger.setLevel(logging.DEBUG)
        self.logger.propagate = False
        
        # --- 配置 Logger ---
        # 检查 handlers 防止重复添加 (当同一个 port 重新创建 Manager 时)
        if not self.logger.handlers:
            # 1. 文件 Handler - 记录所有细节 (DEBUG)
            file_handler = logging.FileHandler(log_file, mode='a', encoding='utf-8')
            # 使用 logging 标准时间戳，包含毫秒；使用 -8s 确保所有级别（包括 WARNING/CRITICAL）对齐
            file_formatter = logging.Formatter('%(asctime)s - %(levelname)-8s - %(message)s')
            file_handler.setFormatter(file_formatter)
            file_handler.setLevel(logging.DEBUG)
            self.logger.addHandler(file_handler)

            # 2. 终端 Handler - 只记录重要信息 (INFO)
            if log_to_console:
                console_handler = logging.StreamHandler()
                console_formatter = logging.Formatter('%(message)s')
                console_handler.setFormatter(console_formatter)
                # 控制台只显示 INFO 及以上，从而隐藏 DEBUG 级别的 [TX]/[RX] 刷屏
                console_handler.setLevel(logging.INFO)
                self.logger.addHandler(console_handler)

        self.ser = serial.Serial(self.port, baudrate=baudrate, timeout=timeout)
        self.prompt_map = {mode: prompt for mode, prompt in PROMPT_CONFIG.items()}
        self.reverse_prompt_map = {v: k for k, v in self.prompt_map.items()}
        
        self.transition_map = {
            (DeviceMode.IBOOT,   DeviceMode.RTOS):    self.iboot_to_rtos,
            (DeviceMode.IBOOT,   DeviceMode.LINUX):   self.iboot_to_linux,
            (DeviceMode.IBOOT,   DeviceMode.IBOOT):   self.iboot_to_iboot,
            
            (DeviceMode.RTOS,    DeviceMode.LINUX):   self.rtos_to_linux,
            (DeviceMode.RTOS,    DeviceMode.IBOOT):   self.rtos_to_iboot,
            (DeviceMode.RTOS,    DeviceMode.RTOS):    self.rtos_to_rtos,
            
            (DeviceMode.LINUX,   DeviceMode.RTOS):    self.linux_to_rtos,
            (DeviceMode.LINUX,   DeviceMode.IBOOT):   self.linux_to_iboot,
            (DeviceMode.LINUX,   DeviceMode.LINUX):   self.linux_to_linux
        }
        self.current_mode = DeviceMode.UNKNOWN

    def kill_process(self, pid):
        """终止指定进程"""
        try:
            os.kill(pid, 9)
            self.logger.info(f"Process {pid} has been terminated.")
        except ProcessLookupError:
            self.logger.info(f"Process {pid} not found.")

    def check_port_occupation(self):
        """获取占用指定端口的进程 ID"""
        try:
            result = subprocess.run(
                ['lsof', self.port],
                capture_output=True,
                text=True,
                check=True
            )
            # 解析输出
            lines = result.stdout.strip().split('\n')
            if len(lines) < 2:
                return
            # 第二行是进程信息，格式：COMMAND PID USER ...
            command = lines[1].split()[0]
            pid = lines[1].split()[1]
            self.logger.info(f'{self.port} 被{command}占用，PID: {pid}')
            self.kill_process(int(pid))
        except subprocess.CalledProcessError as e:
            if "No such file or directory" in e.stderr:
                self.logger.error("port not found")
            else:
                # 未占用                
                pass

    def close(self):
        self.ser.close()

    def _clean_input(self):
        self.ser.reset_output_buffer()
        time.sleep(0.2)

    def _get_prompt(self, retries=30):
        # 这种逻辑流信息用 INFO，可以在控制台看到
        self.logger.info("Checking prompt ...")
        res = b''

        for _ in range(retries):
            self.ser.write(b'\n')
            self.ser.flush()
            time.sleep(0.5)
            data = self.ser.read_all()
            if data:
                res += data
                for prompt in self.prompt_map.values():
                    if prompt in res:
                        if prompt == PROMPT_CONFIG[DeviceMode.LINUX_LOGIN]:
                            # 调试信息，可以考虑用 DEBUG，或者如果是关键路径用 INFO
                            self.logger.info(f'Detected login prompt: {prompt}')
                            self.logger.info("Entering linux, login as root...")
                            self.linux_login_as_root()
                            self._get_prompt()
                        else:
                            return prompt
        if res:
            self.logger.warning(f"Unable to match with any prompt, check response: {res.decode(errors='replace')}")
        else:
            return None

    def send_command_and_read_until(self, command, expected_prompt, match_mode=MatchMode.STRICT_END, timeout=30):
        if isinstance(expected_prompt, str):
            expected_prompt = expected_prompt.encode()
        
        if not command.endswith('\n'):
            command += '\n'
        command_bytes = command.encode()
        self.ser.write(command_bytes)
        self.ser.flush()

        # 去掉了 redundant 的手动时间戳
        # 将原始 I/O 降级为 DEBUG，这样控制台就不会刷屏了
        self.logger.debug(f"[TX] {command.strip()}")

        recv_buffer = b''
        start_time = time.time()
        partial_line = b''

        while True:
            if time.time() - start_time > timeout:
                raise TimeoutError(f"Timeout to wait for prompt <'{expected_prompt}'> within {timeout}s")

            time.sleep(0.001)
            if self.ser.in_waiting:
                recv = self.ser.read(self.ser.in_waiting)
            else:
                recv = b''

            if not recv:
                continue

            recv_buffer += recv

            lines = (partial_line + recv).split(b'\n')
            partial_line = lines.pop()

            for line in lines:
                line_str = line.decode(errors='replace')
                # 原始 RX 数据用 DEBUG 记录
                # 依然按行分割，保证日志文件里每一行都很整齐
                self.logger.debug(f"[RX] {line_str}")

            if match_mode == MatchMode.STRICT_END:
                if recv_buffer.endswith(expected_prompt):
                    if partial_line:
                        # 记录残留部分
                        self.logger.debug(f"[RX] {partial_line.decode(errors='replace')}")
                    break
            elif match_mode == MatchMode.ANY_WHERE:
                if expected_prompt in recv_buffer:
                    if partial_line:
                        self.logger.debug(f"[RX] {partial_line.decode(errors='replace')}")
                    break
            else:
                raise ValueError(f"Unknown mode: {match_mode}")

        return recv_buffer.decode(errors='backslashreplace')

    def get_current_mode(self):
        prompt = self._get_prompt()
        self.logger.debug(f'Detected prompt bytes: {prompt}')
        current_mode = self.reverse_prompt_map.get(prompt, DeviceMode.UNKNOWN)
        self.current_mode = current_mode
        self.logger.info(f"Current mode: {self.current_mode}") # 重要状态变更用 INFO
        return self.current_mode

    def linux_login_as_root(self):
        time.sleep(0.5)
        self.send_command_and_read_until('root', b'Password:', MatchMode.ANY_WHERE, 2)
        time.sleep(0.1)
        self.send_command_and_read_until('alpine', PROMPT_CONFIG[DeviceMode.LINUX], MatchMode.ANY_WHERE, 2)
        time.sleep(0.1)
        self.send_command_and_read_until('\n', PROMPT_CONFIG[DeviceMode.LINUX], MatchMode.ANY_WHERE, 3)

    def _wait_for_iboot_delay_prompt(self, trigger_cmd, timeout):
        iboot_delay_prompt = b"Hit enter to break into the command prompt..."
        self.logger.info(f"Waiting for iboot break prompt via '{trigger_cmd}'...")
        self.send_command_and_read_until(trigger_cmd, iboot_delay_prompt, match_mode=MatchMode.ANY_WHERE, timeout=timeout)

    def _stop_at_iboot(self):
        time.sleep(0.05)
        self.ser.write(b'\n')
        self.ser.flush()
        self.send_command_and_read_until('\n', PROMPT_CONFIG[DeviceMode.IBOOT], MatchMode.ANY_WHERE, 10)

    def iboot_to_rtos(self):
        self.logger.info("Switching: iBoot -> RTOS")
        self.send_command_and_read_until('diags', PROMPT_CONFIG[DeviceMode.RTOS], MatchMode.STRICT_END, 60)

    def iboot_to_linux(self):
        self.logger.info("Switching: iBoot -> Linux")
        self.send_command_and_read_until('fsboot', PROMPT_CONFIG[DeviceMode.LINUX_LOGIN], MatchMode.ANY_WHERE, 90)
        self.linux_login_as_root()

    def iboot_to_iboot(self):
        self.logger.info("Resetting: iBoot -> iBoot")
        self._wait_for_iboot_delay_prompt(trigger_cmd='reset', timeout=30)
        self._stop_at_iboot()

    def rtos_to_iboot(self):
        self.logger.info("Switching: RTOS -> iBoot")
        self._wait_for_iboot_delay_prompt(trigger_cmd='reset', timeout=60)
        self._stop_at_iboot()

    def linux_to_iboot(self):
        self.logger.info("Switching: Linux -> iBoot")
        self._wait_for_iboot_delay_prompt(trigger_cmd='reboot', timeout=90)
        self._stop_at_iboot()

    def rtos_to_rtos(self):
        self.rtos_to_iboot()
        self.iboot_to_rtos()

    def linux_to_linux(self):
        self.linux_to_iboot()
        self.iboot_to_linux()

    def rtos_to_linux(self):
        self.rtos_to_iboot()
        self.iboot_to_linux()

    def linux_to_rtos(self):
        self.linux_to_iboot()
        self.iboot_to_rtos()

    # ---------------- 通用切换 ----------------
    def _reconnect(self):
        self.logger.warning("Connection lost. Attempting to reconnect...") # Warning 级别
        try:
            self.ser.close()
        except:
            pass

        max_retries = 300
        for i in range(max_retries):
            try:
                import glob
                import os
                if os.path.exists(self.ser.port):
                    self.ser.open()
                    self.logger.info("Reconnected successfully!")
                    return
            except (OSError, serial.SerialException):
                pass
            time.sleep(0.1)
        
        raise TimeoutError("Reconnect timed out after reboot.")

    def switch_to(self, target_mode, reset_when_satisfied=False):
        if target_mode not in self.prompt_map.keys():
             raise ValueError(f"Invalid target mode: {target_mode}")
        
        try:
            current_mode = self.get_current_mode()

            if current_mode == DeviceMode.UNKNOWN:
                raise RuntimeError("Unable to identify current mode")

            # INFO 级别显示高层逻辑
            self.logger.info(f"Mode Transition: {current_mode} -> {target_mode}")

            if (self.current_mode == target_mode) and not reset_when_satisfied:
                self.logger.info(f'Already in {target_mode}, skipping transition.')
                return
            else:
                key = (self.current_mode, target_mode)
                transition = self.transition_map.get(key)
                if not transition:
                    raise RuntimeError(f"Unsupported transition: {self.current_mode} -> {target_mode}")
                transition() 
        except (OSError, serial.SerialException):
            self.logger.warning("Connection dropped during transition. Handling reboot...")
            self._reconnect()
            self.logger.info("Resuming transition sequence...")
            time.sleep(0.3)
            self.switch_to(target_mode)

    def send_cmd_rtos(self, command, timeout=30):
        # 这种高层业务动作可以留一条 INFO
        self.logger.info(f"Exec RTOS Cmd: {command}")
        return self.send_command_and_read_until(command, PROMPT_CONFIG[DeviceMode.RTOS], MatchMode.STRICT_END, timeout)

if __name__ == '__main__':
    device = SerialModeManager(port="/dev/cu.kis-14541000-ch-0")
    device.switch_to(DeviceMode.RTOS)
    device.send_cmd_rtos('sn')
