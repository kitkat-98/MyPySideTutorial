import serial
import time
from datetime import datetime
import logging

# 获取一个专用的 logger
serial_logger = logging.getLogger("SerialManager")
# 设置 logger 的级别，INFO 意味着它会处理 INFO, WARNING, ERROR, CRITICAL 级别的日志
serial_logger.setLevel(logging.INFO)
# 防止日志消息向上传递给 root logger，避免重复打印
serial_logger.propagate = False

class SerialModeManager:
    def __init__(self, port, baudrate=115200, timeout=0.1, log_file="serial_log.txt", log_to_console=True):
        self.ser = serial.Serial(port, baudrate=baudrate, timeout=timeout)
        self.logger = serial_logger
        
        # --- 配置 Logger ---
        # 避免重复添加 handlers
        if not self.logger.handlers:
            # 1. 文件 Handler - 始终开启
            # 使用 'a' 模式，表示追加写入
            file_handler = logging.FileHandler(log_file, mode='a', encoding='utf-8')
            file_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            file_handler.setFormatter(file_formatter)
            self.logger.addHandler(file_handler)

            # 2. 终端 Handler - 根据参数决定是否开启
            if log_to_console:
                console_handler = logging.StreamHandler()
                # 终端输出可以简化格式
                console_formatter = logging.Formatter('%(asctime)s - %(message)s')
                console_handler.setFormatter(console_formatter)
                self.logger.addHandler(console_handler)

        self.prompt_map = {
            ']': 'iboot',
            '>': 'rtos',
            '#': 'linux'
        }
        self.reverse_prompt_map = {v: k for k, v in self.prompt_map.items()}
        self.transition_map = {
            ('iboot', 'rtos'): self.iboot_to_rtos,
            ('iboot', 'linux'): self.iboot_to_linux,
            ('iboot', 'iboot'): self.iboot_to_iboot,
            ('rtos', 'linux'): self.rtos_to_linux,
            ('rtos', 'iboot'): self.rtos_to_iboot,
            ('rtos', 'rtos'): self.rtos_to_rtos,
            ('linux', 'rtos'): self.linux_to_rtos,
            ('linux', 'iboot'): self.linux_to_iboot,
            ('linux', 'linux'): self.linux_to_linux
        }

    def close(self):
        self.ser.close()

    def _clean_input(self):
        self.ser.reset_input_buffer()
        time.sleep(0.1)

    def _get_prompt(self, retries=3):
        for _ in range(retries):
            self._clean_input()
            self.ser.write(b'\n')
            self.ser.flush()
            time.sleep(0.2)
            if self.ser.in_waiting:
                data = self.ser.read(self.ser.in_waiting).decode(errors='ignore')
                for prompt in self.prompt_map:
                    if prompt in data:
                        return prompt
            time.sleep(0.2)
        return None

    def get_mode(self):
        prompt = self._get_prompt()
        return self.prompt_map.get(prompt, 'unknown')

    # ---------------- 模式切换核心方法 ----------------

    # ---------------- 模式切换核心方法 ----------------

    def iboot_to_rtos(self):
        self._clean_input()
        self.send_command_and_read_until('rtos', b'>')

    def iboot_to_linux(self):
        self._clean_input()
        self.send_command_and_read_until('linux', b'#')

    def iboot_to_iboot(self):
        self._clean_input()
        self.send_command_and_read_until('reset', b'Enter iBoot', match_mode='anywhere', timeout=10)
        self.send_command_and_read_until('\n', b']', match_mode='anywhere')

    def rtos_to_iboot(self):
        self._clean_input()
        self.send_command_and_read_until('rtos reboot', b'Enter iBoot', match_mode='anywhere', timeout=10)
        self.send_command_and_read_until('\n', b']', match_mode='anywhere')

    def linux_to_iboot(self):
        self._clean_input()
        self.send_command_and_read_until('reboot', b'Enter iBoot', match_mode='anywhere', timeout=10)
        self.send_command_and_read_until('\n', b']', match_mode='anywhere')

    def rtos_to_rtos(self):
        self.rtos_to_iboot()
        self.iboot_to_rtos()

    def linux_to_linux(self):
        self.linux_to_iboot()
        self.iboot_to_linux()

    def rtos_to_linux(self):
        self.rtos_to_iboot()
        self.iboot_to_linux()

    def linux_to_rtos(self):
        self.linux_to_iboot()
        self.iboot_to_rtos()

    # ---------------- 通用切换 ----------------

    def _reconnect(self):
        """
        内部重连机制：当设备因重启而断开时，轮询等待其重新出现。
        """
        self.logger.info("检测到连接断开，尝试重连...")
        try:
            self.ser.close()
        except:
            pass

        # 最多等待 30 秒（重启通常需要几秒）
        max_retries = 300
        for i in range(max_retries):
            # 检查端口是否存在
            # 注意：SerialModeManager 初始化时传入的是 port 路径
            # 我们需要 import glob (类文件头已导入，或者 import os via glob logic)
            # 这里简单起见，尝试直接 open，或者使用 glob 检查文件存在
            # 考虑到虚拟端口和物理端口，检查文件存在比较通用
            try:
                import glob
                # 简单检查路径是否存在 (如果是 /dev/cu.* 这种通配符初始化的，需要保存原始 exact port)
                # 假设初始化时传入的是具体 port
                import os
                if os.path.exists(self.ser.port):
                    # 尝试打开
                    self.ser.open()
                    self.logger.info("重连成功！")
                    return
            except (OSError, serial.SerialException):
                pass
            
            time.sleep(0.1)
        
        raise TimeoutError("设备重启后重连超时")

    def switch_to(self, target_mode):
        if target_mode not in self.reverse_prompt_map:
            raise ValueError(f"目标模式不合法：{target_mode}")
        
        try:
            current_mode = self.get_mode()
            self.logger.info(f"当前模式: {current_mode}, 目标模式: {target_mode}")

            if current_mode == 'unknown':
                # 如果当前模式未知，可能已经在重启过程中？或者读不到。
                # 这里可以抛出异常触发重连，或者视为未知
                # 为安全起见，未知模式下尝试重置可能更好，但目前保持原有逻辑
                raise RuntimeError("无法识别当前设备模式")
            
            if current_mode == target_mode:
                self.logger.info("设备已在目标模式，跳过切换。")
                return

            key = (current_mode, target_mode)
            transition = self.transition_map.get(key)
            if not transition:
                raise RuntimeError(f"不支持从 {current_mode} 到 {target_mode} 的转换")
            
            transition()
            
        except (OSError, serial.SerialException):
            self.logger.warning("在切换模式过程中连接断开（可能是设备重启），准备重连...")
            self._reconnect()
            # 重连后，设备状态可能已变，递归调用自己重新检查和切换
            self.logger.info("重连完成，继续切换流程...")
            # 给一点时间让系统 buffer 稳定
            time.sleep(1)
            self.switch_to(target_mode)

    # ---------------- 实时命令执行 ----------------

    def send_command_and_read_until(self, command, expected_prompt, match_mode='strict_end', timeout=30):
        # 适配：确保 expected_prompt 是 bytes，以便与接收缓冲区比较
        if isinstance(expected_prompt, str):
            expected_prompt = expected_prompt.encode()

        # 发送命令
        if not command.endswith('\n'):
            command += '\n'
        command_bytes = command.encode()
        self.ser.write(command_bytes)
        self.ser.flush()
        
        post_write_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
        write_tag = f"[{post_write_time}] <post-write>: {command.strip()}"
        self.logger.info(write_tag)

        recv_buffer = b''
        start_time = time.time()
        partial_line = b''

        while True:
            if time.time() - start_time > timeout:
                raise TimeoutError(f"Timeout to wait for prompt <'{expected_prompt.decode(errors='ignore')}'> within {timeout}s")

            time.sleep(0.001)
            # 适配：使用 in_waiting 读取，兼容性更好
            if self.ser.in_waiting:
                recv = self.ser.read(self.ser.in_waiting)
            else:
                recv = b''
                
            if not recv:
                continue

            post_read_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
            recv_buffer += recv
            
            # 处理分行日志
            lines = (partial_line + recv).split(b'\n')
            partial_line = lines.pop()  # Save incomplete line

            for line in lines:
                line_str = line.decode(errors='replace').strip() # strip 保持日志整洁
                log_entry = f"[{post_read_time}] <post--read>: {line_str}"
                self.logger.info(log_entry)

            # 检查提示符是否匹配
            if match_mode == 'strict_end':
                # 检查末尾，先去除右侧空白字符以兼容 '# ' 等情况
                if recv_buffer.rstrip().endswith(expected_prompt):
                    # 记录最后残留的部分（如果有）
                    if partial_line:
                        partial_line_str = partial_line.decode(errors='replace')
                        self.logger.info(f"[{post_read_time}] <post--read>: {partial_line_str}")
                    break

            elif match_mode == 'anywhere' or match_mode == 'any_where':
                if expected_prompt in recv_buffer:
                    if partial_line:
                        partial_line_str = partial_line.decode(errors='replace')
                        self.logger.info(f"[{post_read_time}] <post--read>: {partial_line_str}")
                    break
            else:
                raise ValueError(f"Unknown match_mode: {match_mode}")

        return recv_buffer.decode(errors='backslashreplace')

    def send_cmd_linux(self, command, timeout=30):
        """
        在 Linux 模式下发送命令并等待 '#' 提示符。
        返回命令的输出结果。
        """
        return self.send_command_and_read_until(command, expected_prompt='#', match_mode='strict_end', timeout=timeout)


if __name__ == '__main__':
    # a separate logger for the main script's own messages
    main_logger = logging.getLogger("main_script")
    main_logger.setLevel(logging.INFO)
    main_logger.addHandler(logging.StreamHandler())
    
    main_logger.info("--- SerialModeManager 测试 ---")
    # log_to_console=True (默认) 会在终端打印详细日志
    manager = SerialModeManager('/dev/tty.usbserial-XXXXX', log_to_console=True)

    try:
        main_logger.info("自动切换到 Linux...")
        manager.switch_to('linux')

        main_logger.info("在 Linux 下发送命令...")
        manager.send_command('ls -l /tmp', expected_prompt='#', match_mode='strict_end', timeout=8)
        
        main_logger.info("测试完成。")
    except Exception as e:
        main_logger.error(f"测试失败: {e}")
    finally:
        manager.close()
        main_logger.info("连接已关闭。")

