import sys
import logging
from SerialModeManager import SerialModeManager

# --- 配置日志 ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
)

def test_virtual_port(port: str):
    """
    使用 SerialModeManager 连接到指定的虚拟端口并执行测试。
    """
    logging.info(f"--- 开始测试虚拟端口: {port} ---")
    manager = None
    try:
        # 1. 初始化 SerialModeManager
        # 对于虚拟串口，波特率和超时可以随意设置，因为它们不起作用
        manager = SerialModeManager(port, baudrate=9600, timeout=2)
        
        # 2. 检查初始模式
        initial_mode = manager.get_mode()
        logging.info(f"检测到初始模式: {initial_mode}")
        if initial_mode != 'iboot':
            raise RuntimeError(f"预期初始模式为 'iboot'，但检测到 '{initial_mode}'")

        # 3. 切换到 'linux' 模式
        logging.info("正在尝试切换到 'linux' 模式...")
        manager.switch_to('linux')
        final_mode = manager.get_mode()
        logging.info(f"切换成功！当前模式: {final_mode}")
        if final_mode != 'linux':
            raise RuntimeError(f"切换失败，最终模式为 '{final_mode}'")
            
        # 4. 在 Linux 模式下发送命令
        command = 'pattern --showindex 1'
        logging.info(f"在 Linux 模式下发送命令: '{command}'")
        manager.send_command_and_read_until(command, expected_prompt='#', match_mode='strict_end')
        logging.info("命令发送并收到预期提示符，测试通过！")

        # 4.1 测试自定义命令 sn
        logging.info("测试 send_cmd_linux('sn')...")
        sn_output = manager.send_cmd_linux('sn')
        logging.info(f"收到 SN 输出: {sn_output.strip()}")
        if "SN:" not in sn_output:
             raise RuntimeError(f"SN 命令校验失败: Output={sn_output}")
        
        
        # 5. 验证切回 iboot (测试优化后的 linux_to_iboot 逻辑)
        logging.info("正在尝试切回 'iboot' 模式...")
        manager.switch_to('iboot')
        final_mode_iboot = manager.get_mode()
        logging.info(f"切回 iboot 成功！当前模式: {final_mode_iboot}")
        if final_mode_iboot != 'iboot':
            raise RuntimeError(f"切回 iboot 失败，最终模式为 '{final_mode_iboot}'")

    except Exception as e:
        logging.error(f"测试失败: {e}", exc_info=True)
    finally:
        if manager:
            manager.close()
        logging.info(f"--- 测试结束: {port} ---")


if __name__ == '__main__':
    # 从命令行参数获取虚拟端口的名称
    if len(sys.argv) < 2:
        print("用法: python3 test_virtual_port.py <虚拟端口路径>")
        print("例如: python3 test_virtual_port.py /dev/ttys001")
        sys.exit(1)
        
    virtual_port_name = sys.argv[1]
    test_virtual_port(virtual_port_name)
