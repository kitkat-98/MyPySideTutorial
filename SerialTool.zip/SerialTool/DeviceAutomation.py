import time
import glob
import threading
import logging
import os
import shutil
from datetime import datetime
from pathlib import Path

class LogManager:
    """
    日志管理器，负责生成路径、归档日志和创建软链接。
    策略:
    1. 开始时: 在 <Base>/<Date>/_Temp_<Port>/ 下创建日志。
    2. 结束时: 将日志移动到 <Base>/<Date>/<SN>/ 下，并在 <Base>/All_Devices_Index/<SN>/ 创建软链。
    """
    def __init__(self, base_dir="~/Documents/SerialToolLogs"):
        self.base_dir = Path(os.path.expanduser(base_dir))
        
    def get_date_str(self):
        return datetime.now().strftime('%Y-%m-%d')
    
    def get_time_str(self):
        return datetime.now().strftime('%H-%M-%S')

    def setup_temp_log(self, port):
        """准备临时日志路径"""
        date_str = self.get_date_str()
        safe_port = port.replace('/', '_')
        
        # 临时目录: <Base>/<Date>/_Temp
        temp_dir = self.base_dir / date_str / "_Temp"
        temp_dir.mkdir(parents=True, exist_ok=True)
        
        filename = f"{self.get_time_str()}_{safe_port}.log"
        return temp_dir / filename

    def archive_log(self, temp_log_path: Path, sn, status):
        """归档日志"""
        if not temp_log_path.exists():
            return

        date_str = temp_log_path.parent.parent.name # 从路径反推日期，或者是用当前日期
        # 如果跨天了，最好还是用文件创建时的日期（即父目录名）
        
        # 确定目标目录
        if sn and sn != '--' and sn != 'Unknown':
            target_sn_dir = self.base_dir / date_str / sn
        else:
            # 如果没有 SN，就归档到 NoSN 文件夹
            target_sn_dir = self.base_dir / date_str / "NoSN"

        target_sn_dir.mkdir(parents=True, exist_ok=True)
        
        # 移动文件
        # 加上状态后缀，方便查看
        status_safe = status.replace("[bold green]", "").replace("[/bold green]", "").replace("[bold red]", "").replace("[/bold red]", "").strip()
        # 简单的文件名清洗
        status_safe = "".join([c for c in status_safe if c.isalnum() or c in (' ', '_', '-')]).strip()
        
        new_filename = f"{temp_log_path.stem}_{status_safe}{temp_log_path.suffix}"
        final_path = target_sn_dir / new_filename
        
        shutil.move(str(temp_log_path), str(final_path))
        
        # 创建软链 (仅当有有效 SN 时)
        if sn and sn != '--' and sn != 'Unknown':
            self._create_symlink(sn, final_path)
            
    def _create_symlink(self, sn, final_path: Path):
        """在索引目录创建软链"""
        index_dir = self.base_dir / "All_Devices_Index" / sn
        index_dir.mkdir(parents=True, exist_ok=True)
        
        # 软链名包含日期，防止冲突
        link_name = f"{final_path.parent.name}_{final_path.name}" # parent.name 是日期
        link_path = index_dir / link_name
        
        try:
            # 如果存在同名文件/链接，先删除
            if link_path.exists() or link_path.is_symlink():
                link_path.unlink()
            
            # 创建相对路径的软链，或者绝对路径均可。这里用绝对路径稳妥
            link_path.symlink_to(final_path.resolve())
        except Exception as e:
            logging.error(f"Failed to create symlink for {sn}: {e}")


class DeviceAutomation:
    """
    一个通用的多串口设备自动化框架。
    负责：
    1. 自动发现和管理串口设备（支持热插拔）。
    2. 为每个设备启动独立的线程。
    3. 提供线程安全的状态管理。
    4. 执行用户自定义的任务逻辑。
    """
    def __init__(self, task_handler, context=None):
        """
        初始化框架。
        
        :param task_handler: 一个函数，签名应为 f(port, context, reporter)。
        :param context: 传递给 task_handler 的上下文数据 (dict)
        """
        self.task_handler = task_handler
        self.context = context if context is not None else {}
        
        self.log_manager = LogManager()
        
        # managed_devices 结构:
        # {port: {'index': int, 'port': str, 'mode': str, 'status': str, 'sn': str, 'rebooting': bool}}
        self.managed_devices = {}
        self.lock = threading.Lock()
        self.running = True
        
        # 配置内部日志（仅用于框架自身的错误记录）
        logging.basicConfig(
            level=logging.WARNING,
            format='%(asctime)s - %(threadName)s - %(levelname)s - %(message)s',
            filename='automation_framework.log',
            filemode='a'
        )

    def start(self):
        """启动后台扫描线程。"""
        scanner_thread = threading.Thread(target=self._device_scanner, daemon=True)
        scanner_thread.start()

    def get_devices(self):
        """获取当前所有设备的快照（线程安全）。"""
        with self.lock:
            return list(self.managed_devices.values())

    def stop(self):
        """停止框架（主要是扫描循环）。"""
        self.running = False

    def _device_scanner(self):
        """内部扫描循环。"""
        device_counter = 0
        while self.running:
            try:
                # 定义要扫描的模式
                real_device_pattern = '/dev/cu.*-channel0'
                virtual_device_pattern = '/tmp/virtual-serial-port'
                patterns_to_scan = [real_device_pattern, virtual_device_pattern]
                
                all_found_ports = set()
                for pattern in patterns_to_scan:
                    all_found_ports.update(glob.glob(pattern))
                
                with self.lock:
                    # 1. 处理断开的设备
                    ports_in_dict = set(self.managed_devices.keys())
                    missing_ports = [p for p in ports_in_dict if p not in all_found_ports]
                    
                    for port in missing_ports:
                        is_rebooting = self.managed_devices[port].get('rebooting', False)
                        if not is_rebooting:
                            if self.managed_devices[port]['status'] != '[dim]Disconnected[/dim]':
                                self.managed_devices[port]['status'] = '[dim]Disconnected[/dim]'
                                self.managed_devices[port]['mode'] = '[dim]-[/dim]'
                    
                    # 2. 处理新设备或重新连接的设备
                    for port in all_found_ports:
                        should_start_worker = False
                        
                        if port not in self.managed_devices:
                            # 全新设备
                            device_counter += 1
                            self.managed_devices[port] = {
                                'index': device_counter,
                                'port': port,
                                'mode': 'N/A',
                                'status': 'pending',
                                'sn': '--',
                                'rebooting': False
                            }
                            should_start_worker = True
                        
                        elif self.managed_devices[port]['status'] == '[dim]Disconnected[/dim]':
                            # 设备重新连接
                            self.managed_devices[port]['status'] = 'pending'
                            self.managed_devices[port]['mode'] = 'N/A'
                            self.managed_devices[port]['sn'] = '--'
                            self.managed_devices[port]['rebooting'] = False
                            should_start_worker = True
                        
                        if should_start_worker:
                            worker = threading.Thread(
                                target=self._worker_wrapper,
                                args=(port,),
                                daemon=True
                            )
                            worker.start()

            except Exception as e:
                logging.error(f"Scanner thread error: {e}")
            
            time.sleep(0.2) 

    def _worker_wrapper(self, port):
        """
        Worker 包装器。
        负责生命周期管理：日志创建 -> 执行任务 -> 日志归档。
        """
        # 1. 准备日志
        temp_log_path = self.log_manager.setup_temp_log(port)
        
        # 2. 准备上下文（注入 log_path）
        worker_context = self.context.copy()
        worker_context['log_path'] = str(temp_log_path)
        
        # 用于在 finally 块中获取最终状态进行归档
        final_sn = '--'
        final_status = 'End'

        def reporter(**kwargs):
            nonlocal final_sn, final_status
            with self.lock:
                if port in self.managed_devices:
                    # 更新 device info
                    for key, value in kwargs.items():
                        if key == 'sn' and value != '--':
                            final_sn = value # 捕获 SN 用于归档
                        
                        if key == 'status':
                            final_status = value # 捕获状态用于归档

                        if key == 'sn' and value == '--':
                            continue 
                        self.managed_devices[port][key] = value

        try:
            # 3. 执行用户逻辑
            self.task_handler(port, worker_context, reporter)
        except Exception as e:
            logging.error(f"Worker error on {port}: {e}")
            reporter(status=f'[bold red]Error: {str(e).splitlines()[0]}[/bold red]', rebooting=False)
        finally:
            # 4. 日志归档
            try:
                self.log_manager.archive_log(temp_log_path, final_sn, final_status)
            except Exception as e:
                logging.error(f"Failed to archive log for {port}: {e}")
