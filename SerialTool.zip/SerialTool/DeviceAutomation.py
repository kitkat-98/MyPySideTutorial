import time
import glob
import threading
import logging

class DeviceAutomation:
    """
    一个通用的多串口设备自动化框架。
    负责：
    1. 自动发现和管理串口设备（支持热插拔）。
    2. 为每个设备启动独立的线程。
    3. 提供线程安全的状态管理。
    4. 执行用户自定义的任务逻辑。
    """
    def __init__(self, task_handler, context=None):
        """
        初始化框架。
        
        :param task_handler: 一个函数，签名应为 f(port, context, reporter)。
                             - port: 串口号 (str)
                             - context: 传入的上下文对象 (Any)
                             - reporter: 用于更新状态的回调函数，
                               reporter(status='...', mode='...', sn='...', rebooting=False)
        :param context: 传递给 task_handler 的上下文数据 (Any)
        """
        self.task_handler = task_handler
        self.context = context
        
        # managed_devices 结构:
        # {port: {'index': int, 'port': str, 'mode': str, 'status': str, 'sn': str, 'rebooting': bool}}
        self.managed_devices = {}
        self.lock = threading.Lock()
        self.running = True
        
        # 配置内部日志（仅用于框架自身的错误记录）
        logging.basicConfig(
            level=logging.WARNING,
            format='%(asctime)s - %(threadName)s - %(levelname)s - %(message)s',
            filename='automation_framework.log',
            filemode='a'
        )

    def start(self):
        """启动后台扫描线程。"""
        scanner_thread = threading.Thread(target=self._device_scanner, daemon=True)
        scanner_thread.start()

    def get_devices(self):
        """获取当前所有设备的快照（线程安全）。"""
        with self.lock:
            # 返回值的副本，防止由于引用导致的外部并发修改问题（虽然这里只是读）
            # deepcopy 消耗较大，这里假设 dict 的浅拷贝足够用于 UI 展示
            return list(self.managed_devices.values())

    def stop(self):
        """停止框架（主要是扫描循环）。"""
        self.running = False

    def _device_scanner(self):
        """内部扫描循环。"""
        device_counter = 0
        while self.running:
            try:
                # 定义要扫描的模式
                real_device_pattern = '/dev/cu.*-channel0'
                virtual_device_pattern = '/tmp/virtual-serial-port'
                patterns_to_scan = [real_device_pattern, virtual_device_pattern]
                
                all_found_ports = set()
                for pattern in patterns_to_scan:
                    all_found_ports.update(glob.glob(pattern))
                
                with self.lock:
                    # 1. 处理断开的设备
                    ports_in_dict = set(self.managed_devices.keys())
                    missing_ports = [p for p in ports_in_dict if p not in all_found_ports]
                    
                    for port in missing_ports:
                        is_rebooting = self.managed_devices[port].get('rebooting', False)
                        if not is_rebooting:
                            if self.managed_devices[port]['status'] != '[dim]Disconnected[/dim]':
                                self.managed_devices[port]['status'] = '[dim]Disconnected[/dim]'
                                self.managed_devices[port]['mode'] = '[dim]-[/dim]'
                    
                    # 2. 处理新设备或重新连接的设备
                    for port in all_found_ports:
                        should_start_worker = False
                        
                        if port not in self.managed_devices:
                            # 全新设备
                            device_counter += 1
                            self.managed_devices[port] = {
                                'index': device_counter,
                                'port': port,
                                'mode': 'N/A',
                                'status': 'pending',
                                'sn': '--',
                                'rebooting': False
                            }
                            should_start_worker = True
                        
                        elif self.managed_devices[port]['status'] == '[dim]Disconnected[/dim]':
                            # 设备重新连接
                            self.managed_devices[port]['status'] = 'pending'
                            self.managed_devices[port]['mode'] = 'N/A'
                            self.managed_devices[port]['sn'] = '--'
                            self.managed_devices[port]['rebooting'] = False
                            should_start_worker = True
                        
                        if should_start_worker:
                            worker = threading.Thread(
                                target=self._worker_wrapper,
                                args=(port,),
                                daemon=True
                            )
                            worker.start()

            except Exception as e:
                logging.error(f"Scanner thread error: {e}")
            
            time.sleep(0.2) 

    def _worker_wrapper(self, port):
        """
        Worker 包装器。
        负责调用用户的 task_handler，并提供一个安全的 reporter 回调。
        """
        
        def reporter(**kwargs):
            """
            传递给用户的回调函数。
            用户调用 reporter(status='Running', mode='RTOS') 来更新状态。
            """
            with self.lock:
                if port in self.managed_devices:
                    # 即使 Scanner 标记为 Disconnected，只要 Worker 还能汇报，就说明设备“复活”了
                    # 因此无条件接受 Worker 的状态更新，以纠正 Scanner 的潜在误判
                    # current_status = self.managed_devices[port].get('status', '')
                    # if current_status == '[dim]Disconnected[/dim]':
                    #      # 已经被 scanner 标记为断开，worker 可能即将失败或应该退出
                    #      return

                    for key, value in kwargs.items():
                        if key == 'sn' and value == '--':
                            continue # 防止无意覆盖
                        self.managed_devices[port][key] = value

        try:
            # 执行用户逻辑
            self.task_handler(port, self.context, reporter)
        except Exception as e:
            logging.error(f"Worker error on {port}: {e}")
            # 发生未捕获异常时，必须强制清除 rebooting 状态，否则 Scanner 可能会一直以为它在重启而“保护”它，导致无法识别断开
            reporter(status=f'[bold red]Error: {str(e).splitlines()[0]}[/bold red]', rebooting=False)
