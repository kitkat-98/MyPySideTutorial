import os
import pty
import select
import time
import tty

def virtual_device_simulator():
    """
    模拟一个具有 iBoot, RTOS, Linux 模式的串口设备。
    适配 SerialModeManager V2 协议。
    """
    # 定义一个固定的、可预测的符号链接路径
    LINK_NAME = "/tmp/virtual-serial-port"

    # --- 启动模拟 ---
    master_fd, slave_fd = pty.openpty()
    slave_name = os.ttyname(slave_fd)
    
    # 清理可能存在的旧链接并创建新链接
    if os.path.exists(LINK_NAME):
        os.remove(LINK_NAME)
    os.symlink(slave_name, LINK_NAME)

    print(f"--- 虚拟设备已启动 ---")
    print(f"真实设备名: {slave_name}")
    print(f"请在另一个终端中使用固定的符号链接进行连接: {LINK_NAME}")
    print("----------------------")

    # 设置终端为非阻塞模式
    tty.setraw(master_fd)
    os.system(f"stty -f {slave_name} raw -echo")

    # 设备状态机
    current_mode = 'iboot'
    
    # V2 协议提示符
    PROMPT_MAP = {
        'iboot': b'\r\n] ',
        'rtos': b'] :-) ',
        'linux': b'Phone:~ root# ',
        'login': b'login: ',
        'password': b'Password:',
    }

    # 模拟简单的登录状态机
    login_state = 0 # 0: not logging in, 1: waiting for user, 2: waiting for password

    try:
        # 初始显示 iboot 提示符
        os.write(master_fd, b'Welcome to iBoot!\r\n')
        os.write(master_fd, PROMPT_MAP[current_mode])

        while True:
            r, _, _ = select.select([master_fd], [], [], 0.1)
            if not r:
                continue

            try:
                data = os.read(master_fd, 1024)
            except OSError:
                print("--- 连接已关闭 ---")
                break
            
            if not data:
                continue

            command = data.strip()
            response = b''
            
            # --- 状态机逻辑 ---
            if command == b'':
                 # 回车通常只打印提示符
                 if current_mode == 'login':
                     if login_state == 1:
                         response = PROMPT_MAP['login']
                     elif login_state == 2:
                         response = PROMPT_MAP['password']
                 else:
                    response = PROMPT_MAP[current_mode]

            elif current_mode == 'iboot':
                if command == b'diags':
                    current_mode = 'rtos'
                    response = b'Booting RTOS (Diags)...\r\n' + PROMPT_MAP[current_mode]
                elif command == b'fsboot':
                    current_mode = 'login'
                    login_state = 1
                    response = b'Booting Linux...\r\n' + PROMPT_MAP['login']
                elif command == b'reset':
                    # 自循环
                    response = b'Rebooting...\r\nEnter iBoot\r\n' + b'Hit enter to break into the command prompt...\r\n' + PROMPT_MAP[current_mode]
                else:
                    response = b'Unknown command in iBoot\r\n' + PROMPT_MAP[current_mode]

            elif current_mode == 'rtos':
                if command == b'reset':
                    current_mode = 'iboot'
                    response = b'Rebooting from RTOS...\r\nEnter iBoot\r\n' + b'Hit enter to break into the command prompt...\r\n' + PROMPT_MAP[current_mode]
                elif command == b'sn':
                     # V2 main.py 期望: Serial:\s+(\w+)
                     response = b'Serial: SERIAL123456\r\n' + PROMPT_MAP[current_mode]
                elif command.startswith(b'pattern'):
                    # 模拟 execution
                    time.sleep(0.1)
                    response = b'Pattern displayed.\r\n' + PROMPT_MAP[current_mode]
                else:
                    response = b'Executing in RTOS...\r\n' + PROMPT_MAP[current_mode]

            elif current_mode == 'login':
                if login_state == 1: # Waiting for generic login
                     # 任何用户名都接受，或者特定 'root'
                     login_state = 2
                     response = b'\r\n' + PROMPT_MAP['password']
                elif login_state == 2: # Waiting for password
                     # 密码后进入 Linux
                     current_mode = 'linux'
                     login_state = 0
                     response = b'\r\nWelcome to Alpine!\r\n' + PROMPT_MAP['linux']
            
            elif current_mode == 'linux':
                if command == b'reboot':
                    current_mode = 'iboot'
                    response = b'Rebooting from Linux...\r\nEnter iBoot\r\n' + b'Hit enter to break into the command prompt...\r\n' + PROMPT_MAP[current_mode]
                else:
                    response = b'Executing in Linux...\r\n' + PROMPT_MAP[current_mode]
            
            os.write(master_fd, response)

    except KeyboardInterrupt:
        print("\n--- 虚拟设备被用户关闭 ---")
    finally:
        # 清理工作：关闭文件描述符并删除符号链接
        os.close(master_fd)
        os.close(slave_fd)
        if os.path.exists(LINK_NAME):
            os.remove(LINK_NAME)
            print(f"已清理符号链接: {LINK_NAME}")

if __name__ == '__main__':
    virtual_device_simulator()
