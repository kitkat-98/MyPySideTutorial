import time
import logging
import re
from rich.live import Live
from rich.table import Table
from rich.console import Console

from SerialModeManager import SerialModeManager, DeviceMode
from DeviceAutomation import DeviceAutomation

# --- 业务逻辑定义 ---

def parse_image_indexes(input_str):
    """
    解析用户输入，支持:
    - 单个: "3"
    - 列表: "1,3,4"
    - 范围: "1-5"
    - 混合: "1-3, 5, 7-9"
    返回: [1, 2, 3, 5, 7, 8, 9] (已排序去重)
    """
    indexes = set()
    parts = input_str.replace('，', ',').split(',') # 兼容中文逗号
    for part in parts:
        part = part.strip()
        if not part:
            continue
        if '-' in part:
            try:
                start, end = map(int, part.split('-'))
                # 包含 end
                indexes.update(range(start, end + 1))
            except ValueError:
                print(f"警告: 无法解析范围 '{part}'")
        else:
            try:
                indexes.add(int(part))
            except ValueError:
                print(f"警告: 无法解析数字 '{part}'")
    return sorted(list(indexes))

def device_test_sequence(port, context, reporter):
    """
    具体的设备测试逻辑。
    
    :param port: 串口路径
    :param context: 上下文，这里包含 {'image_indices': list}
    :param reporter: 状态汇报回调
    """
    image_indices = context.get('image_indices', [])
    if not image_indices:
        reporter(status='[bold yellow]No Task[/bold yellow]')
        return
        
    # 获取框架注入的日志路径
    log_path = context.get('log_path', 'default_serial.log')
    
    manager = None
    try:
        reporter(status='连接中...', mode='N/A')
        # log_to_console=False 防止刷屏
        # 传入动态生成的 log_file
        manager = SerialModeManager(port, log_file=log_path, log_to_console=False)

        current_mode = manager.get_current_mode()
        reporter(status='跳转模式中...', mode=current_mode, rebooting=True)
        
        # 切换到 RTOS
        manager.switch_to(DeviceMode.RTOS)
        
        current_mode = manager.get_current_mode()
        reporter(status='校验SN...', mode=current_mode, rebooting=False)
        
        # 获取 SN
        sn_output = manager.send_cmd_rtos('sn')
        extracted_sn = 'Unknown'
        match = re.search(r'Serial:\s+(\w+)', sn_output)
        if match:
            extracted_sn = match.group(1)
        
        reporter(status='生成命令...', sn=extracted_sn)
        
        # --- 合成批量命令 ---
        # 格式: pattern --iqc 1; wait 1000; pattern --iqc 3; wait 1000
        commands = []
        for idx in image_indices:
            commands.append(f'pattern --iqc {idx}')
            commands.append('wait 1000')
        
        full_command = "; ".join(commands)
        
        reporter(status=f'执行批量测试 ({len(image_indices)}张)...', sn=extracted_sn)
        # 发送测试命令 (timeout 需要根据图片数量适当增加)
        # 假设一张图 1s，加上命令传输，每张图预留 2s
        timeout = len(image_indices) * 2 + 5
        manager.send_cmd_rtos(full_command, timeout=timeout)

        reporter(status='[bold green]pass[/bold green]')

    except Exception as e:
        error_str = str(e).splitlines()[0]
        # 尝试获取最后已知的模式
        last_mode = 'Error'
        if manager:
            try:
                last_mode = manager.get_current_mode()
            except:
                pass
        
        reporter(status=f'[bold red]fail: {error_str}[/bold red]', mode=last_mode, rebooting=False)
        logging.error(f"[{port}] 业务逻辑异常: {e}")
        
    finally:
        if manager:
            manager.close()

# --- UI 显示逻辑 ---

def generate_table(devices) -> Table:
    """根据设备列表生成 rich Table。"""
    table = Table(title="设备状态监控 (Framework V1)")
    table.add_column("索引", justify="right", style="cyan", no_wrap=True)
    table.add_column("串口号", style="magenta")
    table.add_column("SN", style="blue")
    table.add_column("模式", style="yellow")
    table.add_column("状态", justify="left")

    # 按索引排序
    sorted_devices = sorted(devices, key=lambda x: x['index'])
    for device in sorted_devices:
        table.add_row(
            str(device['index']),
            device['port'],
            device.get('sn', '--'),
            device['mode'],
            device['status']
        )
    return table

def main():
    # 1. 获取用户输入
    try:
        input_str = input("请输入要测试的图片索引 (支持 3, 1-5, 1,3,5): ")
        image_indices = parse_image_indexes(input_str)
        if not image_indices:
            print("未解析到有效的索引，程序退出。")
            return
    except (ValueError, KeyboardInterrupt) as e:
        print(f"无效输入或用户退出。错误: {e}")
        return

    # 2. 初始化自动化框架
    # 将业务逻辑 pass 进去
    automation = DeviceAutomation(
        task_handler=device_test_sequence,
        context={'image_indices': image_indices}
    )
    
    automation.start()

    console = Console()
    console.print("--- 自动化框架已启动 ---", style="bold blue")
    console.print(f"批量测试序列: {image_indices}")
    
    # 3. UI 循环
    try:
        with Live(generate_table([]), screen=True, refresh_per_second=4) as live:
            while True:
                time.sleep(0.5)
                # 从框架获取最新状态
                devices = automation.get_devices()
                live.update(generate_table(devices))
    except KeyboardInterrupt:
        console.print("程序被用户中断，正在退出...", style="bold red")
    finally:
        automation.stop()

if __name__ == '__main__':
    main()