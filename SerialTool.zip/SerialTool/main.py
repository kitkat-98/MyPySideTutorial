import time
import glob
import threading
import logging
from SerialModeManager import SerialModeManager
import serial
from rich.live import Live
from rich.table import Table
from rich.console import Console

# --- 配置日志 ---
# 我们仍然需要一个文件日志来记录 main.py 的高级别错误
# 但终端输出将完全由 rich接管
logging.basicConfig(
    level=logging.WARNING, # 只记录警告及以上级别到文件
    format='%(asctime)s - %(threadName)s - %(levelname)s - %(message)s',
    filename='main_app.log',
    filemode='a'
)

# --- 共享状态 ---
# 这个字典将是所有线程共享的“状态中心”
# 结构: {port: {'index': int, 'port': str, 'mode': str, 'status': str, 'sn': str}}
managed_devices = {}
lock = threading.Lock()

# --- 工作线程函数 ---
import re # 需要引入 regex

def device_worker(port: str, image_index: int):
    """
    为每个设备执行任务的工作线程。
    通过 lock 更新 managed_devices 字典中的状态。
    """
    def update_status(mode='N/A', status='N/A', sn='--', rebooting=False):
        with lock:
            if port in managed_devices:
                # 竞态条件保护
                current_status = managed_devices[port].get('status', '')
                if current_status == '[dim]Disconnected[/dim]':
                    return
                
                managed_devices[port]['mode'] = mode
                managed_devices[port]['status'] = status
                # 只有当 sn 有值时才更新，避免被 '--' 覆盖已有的值
                if sn != '--':
                    managed_devices[port]['sn'] = sn
                # 更新重启标志位
                managed_devices[port]['rebooting'] = rebooting

    manager = None
    try:
        update_status(mode='N/A', status='连接中...')
        manager = SerialModeManager(port, log_to_console=False)

        update_status(mode=manager.get_mode(), status='跳转模式中...')
        # 设置 rebooting=True 以防止 Scanner 在设备重启期间误报断开
        update_status(mode=manager.get_mode(), status='跳转模式中...', rebooting=True)
        
        # 现在的 switch_to 内部已经集成了掉线重连逻辑
        manager.switch_to('linux')

        # 切换完成，清除重启标志
        current_mode = manager.get_mode()
        update_status(mode=current_mode, status='校验SN...', rebooting=False)
        
        # --- 获取 SN ---
        sn_output = manager.send_cmd_linux('sn')
        extracted_sn = 'Unknown'
        match = re.search(r'SN:\s+(\w+)', sn_output)
        if match:
            extracted_sn = match.group(1)
        
        update_status(mode=current_mode, status='发送命令...', sn=extracted_sn)
        
        command = f'pattern --showindex {image_index}'
        manager.send_command_and_read_until(command, expected_prompt='#', match_mode='strict_end', timeout=15)

        update_status(mode=current_mode, status='[bold green]pass[/bold green]', sn=extracted_sn)

    except Exception as e:
        logging.error(f"[{port}] 发生错误: {e}")
        error_str = str(e).splitlines()[0]
        update_status(mode=managed_devices.get(port, {}).get('mode', 'Error'), status=f'[bold red]fail: {error_str}[/bold red]')
    finally:
        if manager:
            manager.close()

# --- 后台扫描线程 ---
def device_scanner(image_index: int):
    """
    在后台运行，持续扫描新设备和断开的设备。
    """
    device_counter = 0
    while True:
        try:
            real_device_pattern = '/dev/cu.*-channel0'
            virtual_device_pattern = '/tmp/virtual-serial-port'
            patterns_to_scan = [real_device_pattern, virtual_device_pattern]
            
            all_found_ports = set()
            for pattern in patterns_to_scan:
                all_found_ports.update(glob.glob(pattern))
            
            with lock:
                # 1. 处理断开的设备 (不再删除，而是标记为 Disconnected)
                ports_in_dict = set(managed_devices.keys())
                missing_ports = [p for p in ports_in_dict if p not in all_found_ports]
                
                for port in missing_ports:
                    # 获取该端口是否处于“重启保护期”
                    is_rebooting = managed_devices[port].get('rebooting', False)
                    
                    # 只有不在重启保护期，才标记为断开
                    if not is_rebooting:
                        if managed_devices[port]['status'] != '[dim]Disconnected[/dim]':
                            managed_devices[port]['status'] = '[dim]Disconnected[/dim]'
                            managed_devices[port]['mode'] = '[dim]-[/dim]'
                    # 如果 is_rebooting 为 True，我们假装没看见它断开了

                # 2. 处理新设备或重新连接的设备
                for port in all_found_ports:

                    should_start_worker = False
                    
                    if port not in managed_devices:
                        # 全新设备
                        device_counter += 1
                        managed_devices[port] = {
                            'index': device_counter,
                            'port': port,
                            'mode': 'N/A',
                            'status': 'pending',
                            'sn': '--'
                        }
                        should_start_worker = True
                    
                    elif managed_devices[port]['status'] == '[dim]Disconnected[/dim]':
                        # 设备重新连接（复用插槽）
                        managed_devices[port]['status'] = 'pending'
                        managed_devices[port]['mode'] = 'N/A'
                        managed_devices[port]['sn'] = '--' # 重置 SN
                        should_start_worker = True
                    
                    # 只有在需要时才启动线程
                    if should_start_worker:
                        worker = threading.Thread(
                            target=device_worker,
                            args=(port, image_index),
                            daemon=True
                        )
                        worker.start()

        except Exception as e:
            logging.error(f"扫描线程异常: {e}")
        
        time.sleep(0.2) # 极速扫描模式，适应生产线快速拔插

# --- 主函数 (显示循环) ---
def generate_table() -> Table:
    """根据共享状态生成一个新的 rich Table。"""
    table = Table(title="设备状态监控")
    table.add_column("索引", justify="right", style="cyan", no_wrap=True)
    table.add_column("串口号", style="magenta")
    table.add_column("SN", style="blue") # 新增 SN 列
    table.add_column("模式", style="yellow")
    table.add_column("状态", justify="left")

    with lock:
        # 按索引排序显示
        sorted_devices = sorted(managed_devices.values(), key=lambda x: x['index'])
        for device in sorted_devices:
            table.add_row(
                str(device['index']),
                device['port'],
                device.get('sn', '--'),
                device['mode'],
                device['status']
            )
    return table

def main():
    try:
        image_index_str = input("请输入要显示的图片索引 (例如: 1, 2, ...): ")
        image_index = int(image_index_str)
        if image_index <= 0:
            raise ValueError("图片索引必须是正整数。")
    except (ValueError, KeyboardInterrupt) as e:
        print(f"无效输入或用户退出。错误: {e}")
        return

    # 启动后台扫描线程
    scanner_thread = threading.Thread(target=device_scanner, args=(image_index,), daemon=True)
    scanner_thread.start()

    console = Console()
    console.print("--- 自动化工具已启动 ---", style="bold blue")
    console.print(f"所有设备将执行命令: 'pattern --showindex {image_index}'")
    
    try:
        with Live(generate_table(), screen=True, refresh_per_second=4) as live:
            while True:
                time.sleep(0.5) # 主线程不需要做太多事，只需活着
                live.update(generate_table())
    except KeyboardInterrupt:
        console.print("程序被用户中断，正在退出...", style="bold red")

if __name__ == '__main__':
    main()