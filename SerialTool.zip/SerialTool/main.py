import time
import logging
import re
from rich.live import Live
from rich.table import Table
from rich.console import Console

from SerialModeManager import SerialModeManager, DeviceMode
from DeviceAutomation import DeviceAutomation

# --- 业务逻辑定义 ---

def device_test_sequence(port, context, reporter):
    """
    具体的设备测试逻辑。
    
    :param port: 串口路径
    :param context: 上下文，这里包含 {'image_index': int}
    :param reporter: 状态汇报回调
    """
    image_index = context.get('image_index', 1)
    
    manager = None
    try:
        reporter(status='连接中...', mode='N/A')
        # log_to_console=False 防止刷屏
        manager = SerialModeManager(port, log_to_console=False)

        current_mode = manager.get_current_mode()
        reporter(status='跳转模式中...', mode=current_mode, rebooting=True)
        
        # 切换到 RTOS
        manager.switch_to(DeviceMode.RTOS)
        
        current_mode = manager.get_current_mode()
        reporter(status='校验SN...', mode=current_mode, rebooting=False)
        
        # 获取 SN
        sn_output = manager.send_cmd_rtos('sn')
        extracted_sn = 'Unknown'
        match = re.search(r'Serial:\s+(\w+)', sn_output)
        if match:
            extracted_sn = match.group(1)
        
        reporter(status='发送命令...', sn=extracted_sn)
        
        # 发送测试命令
        command = f'pattern --iqc {image_index}; wait 1000; pattern --iqc 9'
        manager.send_cmd_rtos(command, timeout=5)

        reporter(status='[bold green]pass[/bold green]')

    except Exception as e:
        error_str = str(e).splitlines()[0]
        # 尝试获取最后已知的模式
        last_mode = 'Error'
        if manager:
            try:
                last_mode = manager.get_current_mode()
            except:
                pass
        
        reporter(status=f'[bold red]fail: {error_str}[/bold red]', mode=last_mode, rebooting=False)
        logging.error(f"[{port}] 业务逻辑异常: {e}")
        
    finally:
        if manager:
            manager.close()

# --- UI 显示逻辑 ---

def generate_table(devices) -> Table:
    """根据设备列表生成 rich Table。"""
    table = Table(title="设备状态监控 (Framework V1)")
    table.add_column("索引", justify="right", style="cyan", no_wrap=True)
    table.add_column("串口号", style="magenta")
    table.add_column("SN", style="blue")
    table.add_column("模式", style="yellow")
    table.add_column("状态", justify="left")

    # 按索引排序
    sorted_devices = sorted(devices, key=lambda x: x['index'])
    for device in sorted_devices:
        table.add_row(
            str(device['index']),
            device['port'],
            device.get('sn', '--'),
            device['mode'],
            device['status']
        )
    return table

def main():
    # 1. 获取用户输入
    try:
        image_index_str = input("请输入要显示的图片索引 (例如: 1, 2, ...): ")
        image_index = int(image_index_str)
        if image_index <= 0:
            raise ValueError("图片索引必须是正整数。")
    except (ValueError, KeyboardInterrupt) as e:
        print(f"无效输入或用户退出。错误: {e}")
        return

    # 2. 初始化自动化框架
    # 将业务逻辑 pass 进去
    automation = DeviceAutomation(
        task_handler=device_test_sequence,
        context={'image_index': image_index}
    )
    
    automation.start()

    console = Console()
    console.print("--- 自动化框架已启动 ---", style="bold blue")
    console.print(f"所有设备将执行命令参数: index={image_index}")
    
    # 3. UI 循环
    try:
        with Live(generate_table([]), screen=True, refresh_per_second=4) as live:
            while True:
                time.sleep(0.5)
                # 从框架获取最新状态
                devices = automation.get_devices()
                live.update(generate_table(devices))
    except KeyboardInterrupt:
        console.print("程序被用户中断，正在退出...", style="bold red")
    finally:
        automation.stop()

if __name__ == '__main__':
    main()