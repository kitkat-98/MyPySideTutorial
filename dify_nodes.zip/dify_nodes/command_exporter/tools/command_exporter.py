from collections.abc import Generator
from typing import Any
import json
import io
import zipfile
import plistlib
import datetime

from dify_plugin import Tool
from dify_plugin.entities.tool import ToolInvokeMessage

class CommandExporterTool(Tool):
    def _invoke(self, tool_parameters: dict[str, Any]) -> Generator[ToolInvokeMessage]:
        """
        Dify Plugin: Command Exporter
        Inputs:
            command_data: JSON String (representing List[Dict])
            export_mode: "text" | "root"
        """
        # 1. 获取参数
        command_data_input = tool_parameters.get("command_data", "[]")
        export_mode = tool_parameters.get("export_mode", "text")
        
        # 2. JSON 解析
        command_data = []
        if isinstance(command_data_input, list):
             command_data = command_data_input
        elif isinstance(command_data_input, str):
            try:
                command_data = json.loads(command_data_input)
            except Exception as e:
                yield self.create_text_message(f"Error parsing command_data JSON: {str(e)}")
                return
        
        if not command_data:
            yield self.create_text_message("No valid command data provided.")
            return

        # 3. 模式分流
        if export_mode == "text":
            yield from self._export_text(command_data)
        elif export_mode == "root":
            yield from self._export_root(command_data)
        else:
            yield self.create_text_message(f"Unsupported export mode: {export_mode}")

    def _export_text(self, data: list) -> Generator[ToolInvokeMessage]:
        """生成 Shell 脚本格式的文本文件"""
        lines = []
        lines.append("#!/bin/bash")
        lines.append("# Exported by SerialTool Assistant")
        lines.append("")
        
        for item in data:
            idx = item.get("index", "?")
            name = item.get("name", "Unknown")
            cmds = item.get("commands", [])
            
            lines.append(f'echo "Item {idx}: {name}"')
            for cmd in cmds:
                lines.append(str(cmd))
            lines.append("") 
        
        content = "\n".join(lines)
        
        # 返回文件 Blob (Filename moved to meta)
        yield self.create_blob_message(
            blob=content.encode("utf-8"),
            meta={
                "mime_type": "text/plain",
                "filename": "commands.sh"
            }
        )

    def _export_root(self, data: list) -> Generator[ToolInvokeMessage]:
        """生成包含 Main.lua 和 Main.plist 的 ZIP 包 (带目录结构)"""
        
        # --- 1. 生成 Main.lua ---
        lua_lines = []
        plist_tests = []
        
        for item in data:
            raw_name = item.get("name", "Unknown")
            func_name = raw_name.replace("|", "_").replace(" ", "_").replace("-", "_")
            if func_name[0].isdigit():
                func_name = "Test_" + func_name
                
            cmds = item.get("commands", [])
            
            lua_lines.append(f"function {func_name}()")
            for cmd in cmds:
                cmd_str = str(cmd)
                if '"' in cmd_str:
                    lua_lines.append(f'    Shell([[{cmd_str}]])')
                else:
                    lua_lines.append(f'    Shell("{cmd_str}")')
            lua_lines.append("end")
            lua_lines.append("")
            
            plist_tests.append({
                "FunctionToExecute": func_name,
                "TimesToRun": 1
            })
            
        lua_content = "\n".join(lua_lines)
        
        # --- 2. 生成 Main.plist ---
        version_str = datetime.datetime.now().strftime("%Y%m%d")
        
        plist_dict = {
            "SequenceName": "ExportedSequence",
            "SequenceVersion": version_str,
            "SchemaFormat": 1,
            "TimesToRun": 1,
            "Tests": plist_tests
        }
        
        plist_bytes = plistlib.dumps(plist_dict, fmt=plistlib.FMT_XML)
        
        # --- 3. 打包 ZIP (带指定目录结构) ---
        zip_buffer = io.BytesIO()
        
        # 目标目录前缀 (注意：Zip内路径通常不以 / 开头)
        target_dir = "TestDir/TestPlatform/Scripts/"
        
        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            # 写入 Lua 文件到指定目录
            zf.writestr(f"{target_dir}Main.lua", lua_content.encode("utf-8"))
            # 写入 Plist 文件到指定目录
            zf.writestr(f"{target_dir}Main.plist", plist_bytes)
            
        zip_bytes = zip_buffer.getvalue()
        
        # 返回 ZIP 文件 Blob (Filename moved to meta)
        yield self.create_blob_message(
            blob=zip_bytes,
            meta={
                "mime_type": "application/zip",
                "filename": "root_package.zip"
            }
        )
