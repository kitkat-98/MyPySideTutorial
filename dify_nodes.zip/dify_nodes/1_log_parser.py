import re
import json

def main(log_text: str) -> dict:
    parsed_items = []
    
    parts = re.split(r'(={5,}Item\d+:.*?\={5,})', log_text)
    header_pattern = re.compile(r'Item(\d+):\s*(.*?)\s*=', re.IGNORECASE)
    cmd_pattern = re.compile(r'\(TX ==> Dut\):(.*?)$', re.MULTILINE)
    
    current_item = None
    
    for part in parts:
        part = part.strip()
        if not part: continue
            
        header_match = header_pattern.search(part)
        if header_match:
            parsed_items.append({
                "index": int(header_match.group(1)),
                "name": header_match.group(2).strip(),
                "commands": []
            })
            current_item = parsed_items[-1]
        elif current_item:
            cmds = cmd_pattern.findall(part)
            for i, cmd in enumerate(cmds):
                clean = cmd.strip()
                if clean:
                    current_item["commands"].append({"seq": i+1, "cmd": clean})
    
    # [关键修改] 将 List 转为 JSON String 返回
    # Ensure ASCII=False to support Chinese characters if any
    return {
        "parsed_json_str": json.dumps(parsed_items, ensure_ascii=False)
    }
