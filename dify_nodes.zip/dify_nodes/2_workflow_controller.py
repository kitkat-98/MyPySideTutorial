import json
from string import Template

def main(intent_str: str, params_str: str, sys_parsed_logs: str, sys_debug_state: str) -> dict:
    # --- 1. 数据加载 ---
    logs = []
    if sys_parsed_logs and isinstance(sys_parsed_logs, str):
        try: logs = json.loads(sys_parsed_logs)
        except: logs = []
            
    state = {"target_id": None, "suspect_ids": []}
    if sys_debug_state and isinstance(sys_debug_state, str):
        try:
            loaded = json.loads(sys_debug_state)
            if isinstance(loaded, dict): state = loaded
        except: pass

    # 参数标准化
    intent = intent_str if intent_str else "OTHER"
    params = params_str if params_str else ""
    
    # 输出变量初始化
    display_text = ""
    command_data = [] # 结构化数据
    export_mode = "none" # none, text, root
    
    # 辅助函数: ID筛选
    def filter_logs(p_str):
        target_ids = set()
        parts = str(p_str).lower().replace("item", "").replace(" and ", ",").split(",")
        for part in parts:
            part = part.strip()
            if not part: continue
            if "-" in part:
                try:
                    s, e = map(int, part.split("-"))
                    target_ids.update(range(s, e + 1))
                except: pass
            else:
                try: target_ids.add(int(part))
                except: pass
        return [i for i in logs if i['index'] in target_ids]

    # --- 2. 业务逻辑 ---
    
    # >>> 场景 A: 导出/查看命令 (VIEW / TXT / ROOT) <<<
    # 兼容 EXPORT_RANGE -> 视为 EXPORT_VIEW
    if intent == "EXPORT_RANGE": 
        intent = "EXPORT_VIEW"

    if intent in ["EXPORT_VIEW", "EXPORT_FILE_TXT", "EXPORT_FILE_ROOT", "EXPORT_ALL"]:
        
        # 统一处理筛选逻辑
        if intent == "EXPORT_ALL":
            selected_items = logs
        else:
            selected_items = filter_logs(params)
        
        if not selected_items:
            display_text = f"No items found matching: {params}"
        else:
            # 1. 生成结构化数据
            for item in selected_items:
                # 提取纯命令字符串列表
                cmds = [c['cmd'] for c in item['commands']]
                command_data.append({
                    "index": item['index'],
                    "name": item['name'],
                    "commands": cmds
                })
            
            # 2. 判断导出模式
            if "TXT" in intent:
                export_mode = "text"
                display_text = f"Preparing **Text File** download for {len(selected_items)} items..."
            elif "ROOT" in intent:
                export_mode = "root"
                display_text = f"Preparing **Root Package** download for {len(selected_items)} items..."
            else:
                export_mode = "none"
                # 3. 视图渲染 (Chat View)
                display_text = render_chat_view(selected_items)

    # >>> 场景 B: 调试流程 (DEBUG) <<<
    elif intent == "DEBUG_START":
        try:
            target = int(params)
            suspects = [i['index'] for i in logs if i['index'] < target] # 简化逻辑：取目标前的所有
            
            if not suspects:
                 display_text = f"Item {target} cannot be debugged (no previous items)."
            else:
                state = {"target_id": target, "suspect_ids": suspects}
                # 初始测试：测前一半
                mid = max(1, len(suspects) // 2)
                to_test_ids = suspects[:mid]
                
                # 渲染
                display_text = render_debug_step(to_test_ids, target, logs)
        except:
            display_text = "Invalid Item ID for debug."

    elif intent == "DEBUG_FEEDBACK":
        if not state.get("target_id"):
            display_text = "No active debug session."
        else:
            is_fail = "fail" in str(params).lower()
            suspects = state["suspect_ids"]
            mid = max(1, len(suspects) // 2)
            tested = suspects[:mid]
            remain = suspects[mid:]
            
            if is_fail:
                state["suspect_ids"] = tested
                status_msg = f"🚨 **Fail Detected.** Narrowing down to {len(tested)} items..."
            else:
                state["suspect_ids"] = remain
                status_msg = f"✅ **Pass Detected.** Checking remaining {len(remain)} items..."

            new_list = state["suspect_ids"]
            
            if len(new_list) == 1:
                # 破案
                culprit = next((i for i in logs if i['index'] == new_list[0]), None)
                display_text = render_culprit_found(culprit, state["target_id"])
                state = {} # Reset
            elif len(new_list) == 0:
                display_text = "Debug ended. No suspects left."
                state = {} # Reset
            else:
                # 下一步
                next_mid = max(1, len(new_list) // 2)
                to_test_ids = new_list[:next_mid]
                display_text = status_msg + "\n\n" + render_debug_step(to_test_ids, state["target_id"], logs)
    
    else:
        display_text = "Ready. Upload logs or ask to export commands."

    # --- 3. 结果返回 ---
    return {
        "display_text": display_text,
        "command_data": json.dumps(command_data, ensure_ascii=False), # 序列化给插件用
        "export_mode": export_mode,
        "new_state_str": json.dumps(state, ensure_ascii=False) if state else ""
    }

# --- 视图渲染模版 (Jinja2-like) ---

def render_chat_view(items):
    out = [f"### Found {len(items)} Items"]
    
    # 1. 聚合所有命令 (One-Click Copy)
    all_cmds = []
    for item in items:
        all_cmds.append(f"// --- Item {item['index']}: {item['name']} ---")
        all_cmds.extend([c['cmd'] for c in item['commands']])
    
    out.append("**🚀 All Commands (Copy & Run):**")
    out.append("```bash")
    out.append("\n".join(all_cmds))
    out.append("```")
    
    out.append("---")
    out.append("**DETAILS:**")

    # 2. 分项展示 (Detailed View)
    for item in items:
        # Template string
        t = Template("""
**Item ${idx}: ${name}**
```bash
${cmds}
```
""")
        cmds_str = "\n".join([c['cmd'] for c in item['commands']])
        out.append(t.substitute(idx=item['index'], name=item['name'], cmds=cmds_str))
    return "\n".join(out)

def render_debug_step(test_ids, target_id, logs):
    # 获取名称用于展示
    test_names = [i['name'] for i in logs if i['index'] in test_ids]
    target_item = next((i for i in logs if i['index'] == target_id), None)
    
    # 组装命令块
    cmds = []
    # Test Group
    for tid in test_ids:
        item = next((i for i in logs if i['index'] == tid), None)
        cmds.append(f"// Item {item['index']}")
        cmds.extend([c['cmd'] for c in item['commands']])
    # Target
    cmds.append(f"// TARGET: Item {target_id}")
    cmds.extend([c['cmd'] for c in target_item['commands']])
    
    return f"""
### 🐞 Debug Step
**Test Scope:** Item {test_ids[0]} - {test_ids[-1]}
**Target:** Item {target_id}

Please run:
```bash
{chr(10).join(cmds)}
```
Reply **Pass** or **Fail**.
"""

def render_culprit_found(culprit, target_id):
    cmds_str = "\n".join([c['cmd'] for c in culprit['commands']])
    return f"""
### 🎯 Culprit Identified!
The interfering item is **Item {culprit['index']}: {culprit['name']}**.

**Commands:**
```bash
{cmds_str}
```
"""